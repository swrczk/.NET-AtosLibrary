﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Exceptions.Pages
{
    public class AddAlbumModel : PageModel
    {
        [BindProperty]
        public AlbumViewModel ViewModel { get; set; }

        public void OnGet()
        {
            ViewModel = new AlbumViewModel();
        }
        
        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
                return Page();
            return RedirectToPage("Index");
        }
    }

    public class AlbumViewModel
    {
        [Display(Name = "Rok wydania")]
        [Required(ErrorMessage = "Pole wymagane")]
        [Range(1920, 2020, ErrorMessage = "Rok wydania powinien mieć wartość między 1920 a 2020")]
        public int ReleaseYear { get; set; }

        [Display(Name = "Nazwa wykonawcy")]
        [Required(ErrorMessage = "Pole wymagane")]
        [MaxLength(50, ErrorMessage = "Wartość powinna wynosić maksymalnie 50 znaków")]
        public string ArtistName { get; set; }
    }
}