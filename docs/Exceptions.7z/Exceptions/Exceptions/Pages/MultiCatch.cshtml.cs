﻿using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Serilog;

namespace Exceptions.Pages
{
    public class MultiCatchModel : PageModel
    {
        public int? Result { get; set; }

        public CalculatorViewModel Calculator { get; set; } = new CalculatorViewModel();

        public void OnGet(int? result)
        {
            Result = result;
        }

        public IActionResult OnPost()
        {
            try
            {
                Result = Calculator.Number / Calculator.DivideBy;
            }
            catch (DivideByZeroException ex)
            {
                Log.Warning(ex, "Somebody tried to divide by zero");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Failed to calculate stuff");
                return RedirectToPage("Error", new { message = "Failed to calculate" });
            }
            return RedirectToPage("MultiCatch", new { result = Result });
        }
    }

    public class CalculatorViewModel
    {
        public int Number { get; set; }
        public int DivideBy { get; set; }
    }
}