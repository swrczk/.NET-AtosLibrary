﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;

namespace Exceptions.Pages.One
{
    public class BasicExceptionModel : PageModel
    {
        [BindProperty]
        public AlbumViewModel Album { get; set; }

        private List<AlbumViewModel> AlbumCollection;

        public void OnGet()
        {

        }

        public void OnPost()
        {
            AlbumCollection.Add(Album);
        }
    }

    public class AlbumViewModel
    {
        public string ArtistName { get; set; }
    }
}