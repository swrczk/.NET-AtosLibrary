﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Exceptions.Pages
{
    public class LoginFormModel : PageModel
    {
        [BindProperty]
        public LoginViewModel ViewModel { get; set; }

        public void OnGet()
        {
            ViewModel = new LoginViewModel();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
                return Page();
            return RedirectToPage("Index");
        }
    }

    public class LoginViewModel
    {
        [Required(ErrorMessage = "Pole wymagane")]
        [DataType(DataType.EmailAddress)]
        public string Username { get; set; }

        [Required(ErrorMessage = "Pole wymagane")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}