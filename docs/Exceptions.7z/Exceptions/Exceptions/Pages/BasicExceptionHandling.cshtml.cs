﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Serilog;

namespace Exceptions.Pages.Two
{
    public class BasicExceptionHandlingModel : PageModel
    {
        [BindProperty]
        public AlbumViewModel Album { get; set; }

        private List<AlbumViewModel> AlbumCollection;

        public void OnGet()
        {

        }

        public IActionResult OnPost()
        {
            try
            {
                AlbumCollection.Add(Album);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Failed to add album");
                return RedirectToPage("Error", new { message = "Failed to add album" });
            }
            return RedirectToPage("Index");
        }
    }

    public class AlbumViewModel
    {
        public string ArtistName { get; set; }
    }
}