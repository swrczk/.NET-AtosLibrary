﻿
namespace AtosLibrary.Infrastructure.Entities
{
    public enum EnumBookItemStatus
    {
        Available = 1,
        Unavailable = 2,
        Deleted = 3
    }
}
