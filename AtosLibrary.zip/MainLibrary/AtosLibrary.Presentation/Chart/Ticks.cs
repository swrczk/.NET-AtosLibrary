﻿namespace AtosLibrary.Presentation.Chart
{
    public class Ticks
    {
        public bool beginAtZero { get; set; }
    }
}