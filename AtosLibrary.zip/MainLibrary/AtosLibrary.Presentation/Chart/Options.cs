﻿using Charts_RazorPage.Models.Chart;

namespace AtosLibrary.Presentation.Chart
{
    public class Options
    {
        public Scales scales { get; set; }
    }
}