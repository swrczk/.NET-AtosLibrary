﻿namespace Charts_RazorPage.Models.Chart
{
    public class Title
    {
        public bool display { get; set; }
        public string text { get; set; }
    }
}