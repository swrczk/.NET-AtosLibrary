﻿using Charts_RazorPage.Models.Chart;

namespace AtosLibrary.Presentation.Chart
{
    public class Data
    {
        public string[] labels { get; set; }
        public Dataset[] datasets { get; set; }
    }
}