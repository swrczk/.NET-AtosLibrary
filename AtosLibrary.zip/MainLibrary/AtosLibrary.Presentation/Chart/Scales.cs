﻿using Charts_RazorPage.Models.Chart;

namespace AtosLibrary.Presentation.Chart
{
    public class Scales
    {
        public yAxes[] yAxes { get; set; }
        public xAxes[] xAxes { get; set; }
    }
}