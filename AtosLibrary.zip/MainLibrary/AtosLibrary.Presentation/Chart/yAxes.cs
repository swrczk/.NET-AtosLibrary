﻿namespace AtosLibrary.Presentation.Chart
{
    public class yAxes
    {
        public string id { get; set; }
        public bool display { get; set; }
        public string type { get; set; }
        public Ticks ticks { get; set; }
    }
}